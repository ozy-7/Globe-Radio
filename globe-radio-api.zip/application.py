from flask import Flask, request, jsonify
from elasticsearch import Elasticsearch

app = Flask(__name__)
application = app


es = Elasticsearch(
    "https://e0zk42nhkp:h09w8k79sy@globe-radio-search-1981816204.eu-central-1.bonsaisearch.net:443"
)

@app.route("/")
def home():
    return "Globe Radio API is running!"

@app.route("/search")
def search():
    query = request.args.get("q", "")
    if not query:
        return jsonify([])

    result = es.search(index="radio_stations", q=f"name:{query}")
    hits = result["hits"]["hits"]
    return jsonify([hit["_source"] for hit in hits])
